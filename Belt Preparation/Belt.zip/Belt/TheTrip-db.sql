SELECT * FROM trips WHERE user_id = 2 ;
SELECT * FROM users;

SELECT * FROM trips WHERE user_id = 1;