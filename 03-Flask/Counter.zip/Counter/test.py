visit_counter = 0

def add(e):
    e += 1
    return e

print(add(visit_counter))