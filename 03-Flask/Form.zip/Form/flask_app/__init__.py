from flask import Flask

app = Flask(__name__)

DATABASE = "TheDojo_schema"